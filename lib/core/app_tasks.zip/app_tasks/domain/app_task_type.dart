enum AppTaskType {
  quizGeneration,
}